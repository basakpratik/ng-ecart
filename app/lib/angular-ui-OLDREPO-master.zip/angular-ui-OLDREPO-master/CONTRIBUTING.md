CONTRIBUTING
============

### AngularUI is currently undergoing a [project restructure](http://angular-ui.github.io/).

Please relocate all your issues to the relevant repo, thanks!
